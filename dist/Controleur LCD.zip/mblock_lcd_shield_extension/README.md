# Extension MBlock contrôle d'écran LCD
Extension pour le contrôle d'un écran LCD (16 caractères / 2 lignes) pour l'IDE MBlock
<br />
# Installation
Téléchargez l'extension en cliquant <a href="https://github.com/paulcoiffier/mblock_lcd_shield_extension/raw/master/dist/Controleur%20LCD.zip">ICI</a>
<br />
Pour l'installer, ouvrez le gestionnaire d'extensions MBlock (choisir "zip file" en tant que type de fichier à ouvrir) puis sélectionnez le fichier téléchargé.

# Utilisation
Pour utiliser l'extension, glissez le bloc "LCD Afficher" dans votre cinématique et renseignez-y le paramètre : 
- <strong>Texte</strong> : Texte à afficher sur l'écran LCD
<br />
    
# Exemple
<br />
![alt tag](https://github.com/paulcoiffier/mblock_lcd_shield_extension/blob/master/screenshot.png)
